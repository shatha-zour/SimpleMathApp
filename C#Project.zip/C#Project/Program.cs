﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Choose the operation you want to perform from the following list :");
                Console.WriteLine("1/ Calculate the area of a circle");
                Console.WriteLine("2/ Calculate the length of the hypotenuse in a right triangle");
                Console.WriteLine("3/ Calculate the area of a rectangle");
                Console.WriteLine("4/ Calculate the product of two numbers");
                Console.WriteLine("5/ Exit ");
                Console.Write("Please enter the transaction number you wish to perform:");


                int Choice = int.Parse(Console.ReadLine());

                if (Choice == 1)
                {
                    double raduis;
                    Console.Write("Enter the radius of the circle : ");
                    raduis = double.Parse(Console.ReadLine());

                    double result1 = Math.PI * raduis * raduis;
                    Console.WriteLine("Area of the circle = " + result1);

                }
                else if (Choice == 2)
                {
                    double a, b, c;
                    Console.Write("Enter the number of the first side : ");
                    a = double.Parse(Console.ReadLine());

                    Console.Write("Enter the number of the second side: ");
                    b = double.Parse(Console.ReadLine());

                    c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));
                    Console.WriteLine("String Length = " + c);
                }
                else if (Choice == 3)
                {
                    double length;
                    Console.Write("Enter the length of the rectangle : ");
                    length = double.Parse(Console.ReadLine());

                    double width;
                    Console.Write("Enter the width of the rectangle : ");
                    width = double.Parse(Console.ReadLine());

                    double result2;
                    result2 = length * width;
                    Console.WriteLine("Area of the rectangle = " + result2);
                }
                else if (Choice == 4)
                {
                    double num1, num2, result3;
                    Console.Write("Enter first number :  ");
                    num1 = double.Parse(Console.ReadLine());

                    Console.Write("Enter scound number :  ");
                    num2 = double.Parse(Console.ReadLine());

                    result3 = num1 * num2;
                    Console.WriteLine("The product of the two numbers = " + result3);

                }
                else if (Choice == 5)
                {
                    Console.WriteLine("Exit");
                }

                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine("Please Enter Number From The List ^_^");
                    continue;
                }


                Console.Write("Press 1.Stop  2.Continue :  ");
                int number = int.Parse(Console.ReadLine());
                if (number == 1)
                {
                    break;
                }
                else if (number == 2)
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("Error !");
                    break;
                }
            }
        }
    }
}
